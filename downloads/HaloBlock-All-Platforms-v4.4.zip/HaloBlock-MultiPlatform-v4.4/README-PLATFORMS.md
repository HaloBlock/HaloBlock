# HaloBlock 4.4 — Cross-browser development package

HaloBlock is a personal experimental ad/tracker blocker. It does not guarantee completely ad-free YouTube, Spotify, streaming websites or every other page. This release adds cross-browser packaging; the filter engine has not been replaced. Do not mistake these builds for signed store releases.

## Current deliverables

- **Chrome**: `HaloBlock-Chrome-v4.4.zip` — unpacked Chromium extension.
- **Edge**: `HaloBlock-Edge-v4.4.zip` — same Chromium extension, separate package.
- **Opera**: `HaloBlock-Opera-v4.4.zip` — same Chromium extension, separate package.
- **Firefox desktop**: `HaloBlock-Firefox-v4.4-unsigned.zip` and `HaloBlock-Firefox-v4.4-UNSIGNED.xpi` — supports an event-page background. XPI is UNSIGNED.
- **Firefox for Android**: shares the Firefox build with `browser_specific_settings.gecko_android`; requires Android verification, Mozilla signing and publishing.
- **Safari for macOS and iOS**: `HaloBlock-Safari-v4.4-SOURCE.zip` — conversion-ready source only, not a native app or signed extension.
- **Android developer guide**: `HaloBlock-Android-Firefox-v4.4-guide.zip` — no APK or Chrome Android support claimed.

Open `platforms.html` in a browser alongside all the ZIPs to see a modern platform download page.

## Firefox implementation

Firefox Manifest V3 uses `background.scripts` rather than `background.service_worker`. The Firefox package preloads `filter-engine.js` then `background.js`. The latter skips `importScripts` in document-based contexts. The Firefox manifest includes a stable Gecko ID and enables the Android target. Automatic list downloads and filtering were **not** verified in real Firefox.

## Safari implementation

Safari packaging is separate from WebExtension source. See `BUILD_ON_MAC.txt` inside the Safari package. Apple's currently documented CLI is `xcrun safari-web-extension-packager`. This source uses reduced dynamic-rule quotas and must be validated in Xcode/Safari. It has not been converted into an Xcode project here because Xcode is not available in this runtime.

## Installation and distribution

**Chrome**: `chrome://extensions` → Developer mode → Load unpacked.

**Edge**: `edge://extensions` → Developer mode → Load unpacked.

**Opera**: `opera://extensions` → Developer mode → Load unpacked.

**Firefox desktop**: `about:debugging` → This Firefox → Load Temporary Add-on → choose `manifest.json`. Temporary until Firefox restart. Mozilla signing is necessary for usual installations.

**Firefox for Android**: publish and sign a tested Firefox Android-compatible build on Mozilla Add-ons, then install from the browser's Add-ons menu.

**Safari**: build Xcode app wrapping the web extension and complete Apple code signing; distribute through the App Store after review.

**Android Chrome**: cannot load ordinary desktop Chrome extensions using the normal desktop developer workflow.

## Testing and limitations

- The cross-browser source modifications are validated using syntax checks, manifest checks, and existing mocked JavaScript unit tests. The included Chromium filtering engine was preserved.
- No live Firefox/Opera/Edge/Safari/Android device integration tests were possible here, and the Safari app wrapper has not been built.
- Ads delivered as first-party video content may still be displayed. The existing YouTube/Shorts and Spotify mitigations remain experimental, not an ad-free Premium replacement.
- Store submission also requires accessibility/privacy review and ensuring filter list licensing and correct extension permissions.

## References

- Firefox cross-browser background scripts: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/background
- Firefox Android metadata: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/browser_specific_settings
- Firefox temporary loading: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
- Safari packager: https://developer.apple.com/documentation/safariservices/packaging-a-web-extension-for-safari
- Opera extension development: https://help.opera.com/en/extensions/
