'use strict';
// Cosmetic filtering is applied to *every* HTTP(S) page, including SPA pages,
// as long as protection is enabled for that site's hostname.
(() => {
  const STYLE_ID='haloblock-cosmetic-filters';
  const FALLBACK = [
    'ins.adsbygoogle','.adsbygoogle','[data-ad-client][data-ad-slot]',
    '[id^="div-gpt-ad-"]','[id^="google_ads_iframe_"]',
    '[class~="ad-slot"]','[class~="ad-unit"]','[class~="ad-banner"]',
    '[class~="ad-wrapper"]','[class~="ad-container"]',
    '[class~="advertisement"]','[class~="advertisement-container"]',
    '[class~="sponsored-ad"]','[aria-label="Advertisement"]',
    'iframe[src*="doubleclick.net"]','iframe[src*="googlesyndication.com"]',
    '[data-testid="ad"]','[data-ad-slot]','[data-adunit]','[data-ad-unit]',
    '[id^="ad-slot-"]','[id^="google_ads_"]',
    '[id*="adfox"]','iframe[src*="adservice.google."]',
    '[class~="ad-placeholder"]','[class~="ad-placement"]',
    '[data-advertisement]','[data-ad-position]',
    'div[class*="advertisement-label"]','[data-google-query-id]'
  ];
  const hostname=location.hostname.toLowerCase();
  let seq=0;
  const matches=(d)=>hostname===d || hostname.endsWith('.'+d);
  function cssBody(selectors) {
    // Individual rules prevent one invalid selector from disabling all others.
    return [...new Set(selectors)].filter(x=>typeof x==='string' && x.length<230)
      .map(x=>`${x}{display:none!important;visibility:hidden!important;}`)
      .join('\n');
  }
  async function refresh() {
    const current=++seq;
    try {
      const pref=await chrome.storage.local.get({enabled:true,excludedHosts:[],cosmeticGlobal:[],cosmeticSites:{},cosmeticExclusions:{}});
      if (current!==seq) return;
      const old=document.getElementById(STYLE_ID);
      if (pref.enabled===false || pref.excludedHosts.some(matches)) {old?.remove();return;}
      const selectors=[...FALLBACK,...(Array.isArray(pref.cosmeticGlobal)?pref.cosmeticGlobal:[])];
      const excepted=new Set();
      for (const [d,values] of Object.entries(pref.cosmeticExclusions||{})) {
        if (matches(d)) for (const item of values||[]) excepted.add(item);
      }
      const siteMap=pref.cosmeticSites||{};
      for (const [domain,values] of Object.entries(siteMap)) {
        if (matches(domain) && Array.isArray(values)) selectors.push(...values);
      }
      if (!document.documentElement) {
        document.addEventListener('readystatechange',refresh,{once:true});return;
      }
      const style=old||document.createElement('style');
      style.id=STYLE_ID;
      style.textContent=cssBody(selectors.filter(s=>!excepted.has(s)));
      if (!old) document.documentElement.appendChild(style);
    } catch(e) {console.warn('HaloBlock cosmetic sync unavailable',e);}
  }
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area==='local' && ['enabled','excludedHosts','cosmeticGlobal','cosmeticSites','cosmeticExclusions'].some(k=>k in changes)) refresh();
  });
  refresh();
})();
