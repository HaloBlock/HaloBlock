'use strict';
// Streaming/ad-heavy sites sometimes install an invisible full-screen anchor
// that opens an ad tab on the first real click. Detect that behavior by visual
// geometry rather than website name. Ordinary visible links are left intact.
(() => {
  let enabled=true;
  const hostname=location.hostname.toLowerCase();
  const matches=domain=>hostname===domain || hostname.endsWith('.'+domain);
  async function sync(){
    try {
      const pref=await chrome.storage.local.get({enabled:true,excludedHosts:[],popupAllowedHosts:[]});
      enabled=pref.enabled!==false && !pref.excludedHosts.some(matches) && !pref.popupAllowedHosts.some(matches);
    } catch { enabled=true; }
  }
  function isAdOverlay(a){
    const box=a.getBoundingClientRect();
    if (box.width < innerWidth*.58 || box.height < innerHeight*.48) return false;
    if (box.width < 300 || box.height < 200) return false;
    if ((a.textContent||'').trim().length>35) return false;
    const style=getComputedStyle(a);
    const opacity=Number.parseFloat(style.opacity||'1');
    const z=Number.parseInt(style.zIndex||'0',10)||0;
    const transparent=/rgba?\(0, 0, 0, 0\)|transparent/.test(style.backgroundColor||'');
    return opacity<.16 || (transparent && z>=999);
  }
  document.addEventListener('click', event=>{
    if (!enabled || !(event.target instanceof Element)) return;
    const a=event.target.closest('a[href][target="_blank"]');
    if (!a || !isAdOverlay(a)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  },true);
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area==='local' && ['enabled','excludedHosts','popupAllowedHosts'].some(k=>k in changes)) sync();
  });
  sync();
})();
