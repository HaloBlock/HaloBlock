'use strict';

const globalToggle = document.getElementById('globalToggle');
const siteToggle = document.getElementById('siteToggle');
const strictPopupToggle = document.getElementById('strictPopupToggle');
const cookieToggle = document.getElementById('cookieToggle');
const siteName = document.getElementById('siteName');
const message = document.getElementById('message');
let config = { enabled: true, excludedHosts: [], blockedHosts: [], popupAllowedHosts: [], remoteRuleCount: 0, remoteFilterStatus: 'Awaiting list download' };
let host = null;
let tabId = null;
let busy = false;

async function getCurrentSite() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id ?? null;
  try {
    const url = new URL(tab.url);
    return ['http:', 'https:'].includes(url.protocol) ? url.hostname.toLowerCase() : null;
  } catch {
    return null;
  }
}

function isExcluded(domain) {
  return config.excludedHosts.some(x => domain === x || domain.endsWith(`.${x}`));
}

function render() {
  const siteOn = !!host && config.enabled && !isExcluded(host);
  const globalOn = config.enabled;
  globalToggle.checked = globalOn;
  siteToggle.checked = siteOn;
  strictPopupToggle.checked = !!host && !config.popupAllowedHosts.some(x => host === x || host.endsWith(`.${x}`));
  strictPopupToggle.disabled = busy || !siteOn;
  cookieToggle.checked = config.autoRejectCookies !== false;
  cookieToggle.disabled = busy || !globalOn;
  globalToggle.disabled = busy;
  siteToggle.disabled = busy || !globalOn || !host;
  siteName.textContent = host || 'Unavailable on this page';
  document.getElementById('filterCount').textContent = ((window.builtinCount||0) + (config.remoteRuleCount||0) + (config.blockedHosts?.length||0)).toLocaleString();
  document.getElementById('cosmeticStatus').textContent = globalOn ? 'Active' : 'Off';
  const online = document.getElementById('onlineStatus');
  if (online) online.textContent = config.remoteRuleCount ? `${config.remoteRuleCount.toLocaleString()} active` : 'Built-in only';
  const sync = document.getElementById('syncStatus');
  if (sync) sync.textContent = config.remoteFilterStatus || 'Awaiting list download';
  document.getElementById('hero').classList.toggle('off', !siteOn);
  document.getElementById('heroEyebrow').textContent = siteOn ? 'ON' : 'PAUSED';
  document.getElementById('heroTitle').textContent = siteOn ? 'Protection is on' : (globalOn ? 'Paused on this site' : 'Protection is off');
  document.getElementById('heroDescription').textContent = siteOn
    ? 'Filtering known ad and tracking requests on this site.'
    : (globalOn ? 'Filtering is paused for this website.' : 'Enable protection to reduce ads and tracking.');
  document.getElementById('heroFootnote').textContent = siteOn ? 'Privacy controls are active for this page.' : 'You can switch protection back on anytime.';
}

async function update(patch) {
  busy = true;
  message.textContent = '';
  render();
  try {
    const response = await chrome.runtime.sendMessage({ type: 'UPDATE_SETTINGS', patch });
    if (!response?.ok) throw new Error(response?.error || 'Unable to save setting.');
    config = {...config, ...response.data};
    if (tabId !== null) await chrome.tabs.reload(tabId).catch(() => {});
  } catch (err) {
    message.textContent = err.message;
    config = await chrome.storage.local.get(config);
  } finally {
    busy = false;
    render();
  }
}

globalToggle.addEventListener('change', () => update({ enabled: globalToggle.checked }));
siteToggle.addEventListener('change', () => {
  if (!host) return;
  const excludedHosts = new Set(config.excludedHosts);
  if (siteToggle.checked) {
    // Remove any exception that also covers the selected hostname.
    for (const domain of [...excludedHosts]) {
      if (host === domain || host.endsWith(`.${domain}`)) excludedHosts.delete(domain);
    }
  } else {
    excludedHosts.add(host);
  }
  update({ excludedHosts: [...excludedHosts] });
});
cookieToggle.addEventListener('change', () => update({ autoRejectCookies: cookieToggle.checked }));
strictPopupToggle.addEventListener('change', () => {
  if (!host) return;
  const popupAllowedHosts = new Set(config.popupAllowedHosts);
  if (strictPopupToggle.checked) {
    for (const domain of [...popupAllowedHosts]) {
      if (host === domain || host.endsWith(`.${domain}`)) popupAllowedHosts.delete(domain);
    }
  } else {
    popupAllowedHosts.add(host);
  }
  update({ popupAllowedHosts: [...popupAllowedHosts] });
});
document.getElementById('optionsButton').addEventListener('click', () => chrome.runtime.openOptionsPage());
document.getElementById('moreSettings').addEventListener('click', () => chrome.runtime.openOptionsPage());

(async () => {
  try {
    const [saved, current, response] = await Promise.all([
      chrome.storage.local.get(config),
      getCurrentSite(),
      Promise.all(['rules/core.json', 'rules/popups.json'].map(path => fetch(chrome.runtime.getURL(path))))
    ]);
    config = {...config,...saved};
    host = current;
    let total = 0;
    for (const file of response) if (file.ok) total += (await file.json()).length;
    window.builtinCount = total;
  } catch (err) {
    message.textContent = `Loading error: ${err.message}`;
  }
  render();
  await showRecentActivity();
  if (host === 'youtube.com' || host?.endsWith('.youtube.com')) {
    const panel = document.getElementById('youtubeDiagnostics');
    panel.hidden = false;
    try {
      const result = await chrome.tabs.sendMessage(tabId, {type:'YT_GET_DIAGNOSTICS'});
      document.getElementById('youtubeEngineStatus').textContent = result?.ready ? 'Running' : 'Not detected';
      document.getElementById('youtubeEngineDetails').textContent = result?.ready
        ? `${result.pruneCount} metadata rewrites in this tab${result.adShowing ? ' · An ad is currently showing' : ''}`
        : 'Reload YouTube and check that the extension is enabled.';
    } catch {
      document.getElementById('youtubeEngineStatus').textContent = 'Not detected';
      document.getElementById('youtubeEngineDetails').textContent = 'Reload YouTube and reopen HaloBlock.';
    }
  }
})();

// These are browser-reported DNR rule matches in the selected tab, not
// estimated ads. User action opening the popup grants activeTab permission.
async function showRecentActivity() {
  const number = document.getElementById('recentMatches');
  const details = document.getElementById('recentDetails');
  if (tabId === null || !host) {
    number.textContent = 'N/A';
    details.textContent = 'Open a regular webpage to inspect recent rule matches.';
    return;
  }
  try {
    const result = await chrome.declarativeNetRequest.getMatchedRules({tabId});
    const all = result.rulesMatchedInfo || [];
    // Ignore allow and allowAllRequests events. Remote rules were installed
    // as blocks then navigation blocks then exceptions, in that exact order.
    const endRemote = 10000 + (config.remoteBlockRuleCount || 0) + (config.popupNavigationRules || 0);
    const blocked = all.filter(match => {
      const {rulesetId, ruleId} = match.rule || {};
      if (['core_ads', 'popups', 'compiled_subscriptions'].includes(rulesetId)) return true;
      if (rulesetId !== '_dynamic') return false;
      return (ruleId >= 100 && ruleId < 3600) || (ruleId >= 10000 && ruleId < endRemote);
    });
    number.textContent = blocked.length.toLocaleString();
    details.textContent = 'In this tab, within Chrome’s recent matching window (about 5 minutes). Not all ads are detectable.';
  } catch {
    number.textContent = 'N/A';
    details.textContent = 'This Chrome build did not provide recent rule-match data.';
  }
}
