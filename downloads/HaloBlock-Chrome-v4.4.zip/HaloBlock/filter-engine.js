'use strict';
// A deliberately conservative subset of Adblock Plus network/cosmetic syntax.
// Unsupported syntax is skipped instead of converted into a broad, unsafe block.
const HaloBlockFilterEngine = (() => {
  const types = ['sub_frame','script','image','stylesheet','font','object','xmlhttprequest','ping','media','websocket','other'];
  const typeMap = {
    script: 'script', image: 'image', stylesheet: 'stylesheet', css: 'stylesheet',
    font: 'font', object: 'object', xmlhttprequest: 'xmlhttprequest', xhr: 'xmlhttprequest',
    subdocument: 'sub_frame', media: 'media', websocket: 'websocket', ping: 'ping',
    other: 'other', document: 'main_frame'
  };
  const unsupported = /^(?:redirect|redirect-rule|rewrite|removeparam|csp|header|urltransform|permissions|cookie|replace|path|method|denyallow|to|from|ipaddress|queryprune|inline-script|inline-font|generichide|specifichide|elemhide|ghide|ehide|badfilter|removeheader|referrerpolicy|hls|jsonprune|xmlprune|stealth|popunder|webrtc|empty|mp4|frame|~frame)(?:=|$)/i;
  function validDomain(domain) {
    return typeof domain === 'string' && domain.length <= 253 && domain.includes('.') &&
      /^[a-z\d-]+(?:\.[a-z\d-]+)+$/.test(domain) &&
      domain.split('.').every(x => x.length <= 63 && !x.startsWith('-') && !x.endsWith('-'));
  }
  function network(line) {
    if (!line || line[0] === '!' || line[0] === '#' || line[0] === '[') return null;
    let exception = false;
    if (line.startsWith('@@')) { exception = true; line = line.slice(2); }
    if (line.startsWith('/') && line.endsWith('/')) return null; // ABP regex, not DNR urlFilter syntax
    const split = line.indexOf('$');
    let pattern = split === -1 ? line : line.slice(0, split);
    const opts = split === -1 ? [] : line.slice(split+1).split(',');
    if (!pattern || pattern.length > 650 || pattern.includes('#') || pattern.includes('{') || pattern.includes('}')) return null;
    if (/^\d+\.\d+\.\d+\.\d+\s+/.test(pattern)) pattern = '||' + pattern.split(/\s+/)[1] + '^';
    if (pattern.startsWith('||') && pattern.endsWith('^') && !validDomain(pattern.slice(2,-1))) {
      // Complex domain anchors are supported by DNR, but they are not plain domains.
      if (!/^\|\|[a-z\d.*-]+\.[a-z\d.*-]+\^$/i.test(pattern)) return null;
    }
    if (/^[a-z\d-]+(?:\.[a-z\d-]+)+$/.test(pattern)) pattern = `||${pattern}^`;
    if (pattern.length < 5) return null;
    if (pattern.slice(2, -1).includes('|')) return null;
    if (pattern.includes('\\') || /\s/.test(pattern)) return null;
    const condition = { urlFilter: pattern };
    const positive = new Set();
    const negative = new Set();
    let hasPositiveType = false;
    let third = null;
    let important = false;
    for (const opt of opts) {
      const v = opt.toLowerCase();
      if (!v) return null;
      if (unsupported.test(v)) return null;
      if (v === 'third-party') { third = 'thirdParty'; continue; }
      if (v === 'important') { if (exception) return null; important = true; continue; }
      if (v === '~third-party' || v === 'first-party') { third = 'firstParty'; continue; }
      if (v === 'popup') { positive.add('main_frame'); hasPositiveType = true; continue; }
      if (v === 'all') { for (const t of [...types, 'main_frame']) positive.add(t); hasPositiveType = true; continue; }
      if (v === 'match-case') { condition.isUrlFilterCaseSensitive = true; continue; }
      if (v.startsWith('domain=')) {
        const allow = [], deny = [];
        for (let domain of v.slice(7).split('|')) {
          const negate = domain.startsWith('~');
          if (negate) domain = domain.slice(1);
          if (!validDomain(domain)) return null;
          (negate ? deny : allow).push(domain);
        }
        if (allow.length) condition.initiatorDomains = allow;
        if (deny.length) condition.excludedInitiatorDomains = deny;
        continue;
      }
      if (v.startsWith('~') && typeMap[v.slice(1)]) { negative.add(typeMap[v.slice(1)]); continue; }
      if (typeMap[v]) { positive.add(typeMap[v]); hasPositiveType = true; continue; }
      return null; // never discard unknown modifiers (could broaden a dangerous filter)
    }
    const selected = hasPositiveType ? [...positive] : [...types];
    condition.resourceTypes = selected.filter(type => !negative.has(type));
    // Ordinary filter-list rules are sub-resource rules. Only explicitly $document
    // rules can affect top-level navigation.  Avoid blocking arbitrary visited sites.
    if (hasPositiveType && positive.has('main_frame')) condition.resourceTypes.push('main_frame');
    if (!condition.resourceTypes.length) return null;
    if (third) condition.domainType = third;
    // Preserve the list author's first/third-party semantics. Generic rules
    // without $third-party intentionally cover first-party served ads too.
    return { action: {type: exception ? 'allow' : 'block'}, priority: exception ? 5 : (important ? 10 : 2), condition };
  }
  const selectorBan = /(?:\{ |\{|\}|\0|:has-text\(|:matches-css\(|:xpath\(|:upward\(|:remove\(|:style\(|:contains\(|:-abp-|:-abp|\+js\(|\/deep\/|::shadow|:matches-path\()/i;
  function cosmetic(line) {
    // Supports generic ##selector and site1,site2##selector. Skips exceptions
    // and procedural/scriptlet rules rather than silently changing their meaning.
    if (!line || line[0] === '!' || line.startsWith('@@')) return null;
    const isException=line.includes('#@#');
    const token=isException?'#@#':'##';
    const i=line.indexOf(token);
    if (i < 0 || line.includes('#?#') || line.includes('#%#') || line.includes('##+js')) return null;
    let domains = line.slice(0,i);
    const selector = line.slice(i+token.length).trim();
    if (!selector || selector.length > 220 || selectorBan.test(selector) || /[\r\n]/.test(selector)) return null;
    if (domains.includes('~')) return null; // negated domain scopes require full exception support
    if (!domains) return { selector, domains: [], exception:isException };
    const domainList = domains.split(',').map(d=>d.trim().toLowerCase());
    if (domainList.length > 8 || domainList.some(d=>!validDomain(d))) return null;
    return { selector, domains: domainList, exception:isException };
  }
  function parse(text, quota = {block: 1000, allow: 250, cosmetic: 1000}) {
    const blocks=[], allows=[], generic=[], site={}, siteExclusions={};
    const seen=new Set(), seenCSS=new Set();
    let cosmeticCount=0, processed=0, skipped=0;
    for (const raw of text.split(/\r?\n/)) {
      const line=raw.trim();
      if (!line || line.startsWith('!') || line.startsWith('[')) continue;
      processed++;
      if (line.includes('##') || line.includes('#@#') || line.includes('#?#')) {
        const value=cosmetic(line);
        if (!value || cosmeticCount>=quota.cosmetic) { skipped++; continue; }
        const key=(value.domains.join(',')||'*')+value.selector+(value.exception?'@':'');
        if (seenCSS.has(key)) continue;
        seenCSS.add(key);
        if (!value.domains.length && !value.exception) generic.push(value.selector);
        else for (const domain of value.domains) {
          (value.exception?siteExclusions:site)[domain]??=[];
          (value.exception?siteExclusions:site)[domain].push(value.selector);
        }
        cosmeticCount++;
        continue;
      }
      if (line.includes('#')) { skipped++; continue; }
      const parsed=network(line);
      if (!parsed) { skipped++; continue; }
      const target=parsed.action.type==='allow' ? allows : blocks;
      if (target.length>= (parsed.action.type==='allow' ? quota.allow : quota.block)) continue;
      const key=JSON.stringify(parsed.condition)+parsed.action.type;
      if (seen.has(key)) continue;
      seen.add(key);
      target.push(parsed);
    }
    return {blocks, allows, generic, site, siteExclusions, processed, skipped};
  }
  return { parse, network, cosmetic, validDomain, types };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = HaloBlockFilterEngine;
