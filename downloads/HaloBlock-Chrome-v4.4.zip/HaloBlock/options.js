'use strict';

const MAX_CUSTOM_DOMAINS = 3500;
const data = { excludedHosts: [], blockedHosts: [], popupAllowedHosts: [] };
const status = document.getElementById('status');
let busy = false;

function normalizeDomain(value) {
  if (typeof value !== 'string') return null;
  const domain = value.trim().toLowerCase().replace(/\.$/, '');
  if (!domain || domain.length > 253 || domain.includes('..')) return null;
  if (!/^[a-z0-9-]+(?:\.[a-z0-9-]+)*$/.test(domain)) return null;
  if (domain.split('.').some(p => p.length > 63 || p.startsWith('-') || p.endsWith('-'))) return null;
  return domain;
}

function parseLine(line) {
  let value = line.trim();
  if (!value || value.startsWith('!') || value.startsWith('#') || value.startsWith('@@')) return null;
  const hosts = value.match(/^(?:0\.0\.0\.0|127\.0\.0\.1|::1)\s+([^\s#]+)/);
  if (hosts) value = hosts[1];
  else if (value.startsWith('||') && value.endsWith('^')) value = value.slice(2, -1);
  return normalizeDomain(value);
}

function show(message, error = false) {
  status.textContent = message;
  status.style.color = error ? '#ffaf9f' : '#abefba';
}

function renderList(id, key, emptyText) {
  const list = document.getElementById(id);
  list.replaceChildren();
  const domains = data[key];
  document.getElementById(({excludedHosts:'trustedCount',blockedHosts:'blockedCount',popupAllowedHosts:'strictCount'})[key]).textContent = domains.length;
  if (!domains.length) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = emptyText;
    list.appendChild(li);
  }
  for (const domain of domains) {
    const li = document.createElement('li');
    const label = document.createElement('span');
    label.textContent = domain;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.textContent = 'Remove';
    remove.disabled = busy;
    remove.setAttribute('aria-label', `Remove ${domain}`);
    remove.addEventListener('click', () => save(key, data[key].filter(x => x !== domain)));
    li.append(label, remove);
    list.appendChild(li);
  }
}
function render() {
  renderList('trustedList', 'excludedHosts', 'No website exceptions yet.');
  renderList('blockedList', 'blockedHosts', 'No custom blocked domains yet.');
  renderList('strictList', 'popupAllowedHosts', 'No popup exceptions. Strict popup blocking is active everywhere.');
  document.querySelectorAll('button, input, textarea').forEach(control => { control.disabled = busy; });
}

async function save(key, domains) {
  if (busy) return;
  busy = true;
  show('Saving filters…');
  render();
  try {
    const response = await chrome.runtime.sendMessage({ type: 'UPDATE_SETTINGS', patch: { [key]: domains } });
    if (!response?.ok) throw new Error(response?.error || 'Could not save changes.');
    data.excludedHosts = response.data.excludedHosts;
    data.blockedHosts = response.data.blockedHosts;
    data.popupAllowedHosts = response.data.popupAllowedHosts;
    show('Filters updated successfully.');
    return true;
  } catch (err) {
    show(err.message, true);
    return false;
  } finally {
    busy = false;
    render();
  }
}

function addOne(event, key, inputId) {
  event.preventDefault();
  const input = document.getElementById(inputId);
  const domain = normalizeDomain(input.value);
  if (!domain) return show('Use a valid hostname, such as ads.example.com.', true);
  if (data[key].includes(domain)) return show('That domain is already in the list.');
  const limit = key === 'blockedHosts' ? MAX_CUSTOM_DOMAINS : (key === 'popupAllowedHosts' ? 500 : 1000);
  if (data[key].length >= limit) return show(`Limit reached (${limit} domains).`, true);
  save(key, [...data[key], domain]);
  input.value = '';
}

document.getElementById('trustedForm').addEventListener('submit', e => addOne(e, 'excludedHosts', 'trustedInput'));
document.getElementById('blockedForm').addEventListener('submit', e => addOne(e, 'blockedHosts', 'blockedInput'));
document.getElementById('strictForm').addEventListener('submit', e => addOne(e, 'popupAllowedHosts', 'strictInput'));
document.getElementById('importButton').addEventListener('click', () => {
  const lines = document.getElementById('importBox').value.split(/\r?\n/);
  const entries = lines.map(parseLine).filter(Boolean);
  const merged = [...new Set([...data.blockedHosts, ...entries])];
  const rejected = lines.filter(line => line.trim() && !line.trim().startsWith('!') && !line.trim().startsWith('#') && !parseLine(line)).length;
  if (!entries.length) return show('No supported domain entries were found.', true);
  if (merged.length > MAX_CUSTOM_DOMAINS) return show(`Import would exceed the ${MAX_CUSTOM_DOMAINS}-domain limit.`, true);
  const newlyAdded = merged.length - data.blockedHosts.length;
  save('blockedHosts', merged).then(ok => {
    if (ok) {
      document.getElementById('importBox').value = '';
      show(`Added ${newlyAdded} new domains (${rejected} unsupported lines ignored; duplicates skipped).`);
    }
  });
});

(async () => {
  try {
    const saved = await chrome.storage.local.get({ excludedHosts: [], blockedHosts: [], popupAllowedHosts: [] });
    data.excludedHosts = saved.excludedHosts;
    data.blockedHosts = saved.blockedHosts;
    data.popupAllowedHosts = saved.popupAllowedHosts;
  } catch (err) {
    show(`Unable to load settings: ${err.message}`, true);
  }
  render();
  await showFilters();
})();

async function showFilters() {
  const result=await chrome.runtime.sendMessage({type:'GET_FILTER_STATUS'});
  if (!result?.ok) return show('Filter status unavailable',true);
  const info=result.data;
  document.getElementById('onlineCount').textContent=(info.remoteRuleCount||0).toLocaleString()+' rules, including '+(info.popupNavigationRules||0).toLocaleString()+' confirmed ad destinations';
  document.getElementById('filterState').textContent=(info.remoteFilterStatus||'Not updated')+(info.lastFilterUpdate?' · Last sync '+new Date(info.lastFilterUpdate).toLocaleString():'');
  const list=document.getElementById('sourceStates');list.replaceChildren();
  for (const src of info.sourceStatus||[]) {
    const li=document.createElement('li');li.textContent=src.name+': '+(src.ok?`${src.rules.toLocaleString()} matched rules`:(src.error||'Unavailable'));list.appendChild(li);
  }
}
document.getElementById('refreshFilters').addEventListener('click',async()=>{
  const button=document.getElementById('refreshFilters');button.disabled=true;button.textContent='Updating…';
  try {
    const response=await chrome.runtime.sendMessage({type:'UPDATE_FILTERS'});
    if (!response?.ok) throw new Error(response?.error||'Could not update lists');
    show('Filter lists successfully updated. Reload open webpages to apply the latest cosmetic rules.');
  } catch(e) {show(e.message,true);}
  finally {button.disabled=false;button.textContent='Update filter lists now';await showFilters();}
});

// Spotify playback handling is independent of the per-website network lists.
(async()=>{
  const toggle=document.getElementById('spotifyMuteAds');
  const saved=await chrome.storage.local.get({spotifyMuteAds:true});
  toggle.checked=saved.spotifyMuteAds!==false;
  toggle.addEventListener('change',async()=>{
    toggle.disabled=true;
    const answer=await chrome.runtime.sendMessage({type:'UPDATE_SETTINGS',patch:{spotifyMuteAds:toggle.checked}}).catch(e=>({ok:false,error:e.message}));
    if (!answer?.ok) {toggle.checked=!toggle.checked;show(answer?.error||'Could not save Spotify preference',true);}
    else show(toggle.checked?'Spotify ad muting enabled.':'Spotify ad muting disabled.');
    toggle.disabled=false;
  });
})();

(async()=>{
  const toggle=document.getElementById('autoRejectCookies');
  const saved=await chrome.storage.local.get({autoRejectCookies:true});
  toggle.checked=saved.autoRejectCookies!==false;
  toggle.addEventListener('change',async()=>{
    toggle.disabled=true;
    const result=await chrome.runtime.sendMessage({type:'UPDATE_SETTINGS',patch:{autoRejectCookies:toggle.checked}}).catch(e=>({ok:false,error:e.message}));
    if(!result?.ok){toggle.checked=!toggle.checked;show(result?.error||'Unable to change cookie setting',true);}
    else show(toggle.checked?'Automatic cookie rejection enabled for supported providers.':'Automatic cookie rejection disabled.');
    toggle.disabled=false;
  });
})();
