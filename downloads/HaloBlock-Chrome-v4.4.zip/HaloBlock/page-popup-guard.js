'use strict';
// Strong protection on ALL websites, not just a hand-picked domain list.
// This blocks scripted window.open() popups, including those triggered by user
// clicks. Websites requiring popup OAuth/payment can be exempted in the UI.
(() => {
  if (window.__haloblockPopupGuardInstalled) return;
  Object.defineProperty(window, '__haloblockPopupGuardInstalled', {value:true});
  let enabled=true, strict=true;
  const nativeOpen=window.open;
  document.addEventListener('haloblock:popup-policy', event => {
    const state=event.detail;
    if (!state || typeof state!=='object') return;
    if (typeof state.enabled==='boolean') enabled=state.enabled;
    if (typeof state.strict==='boolean') strict=state.strict;
  });
  window.open=function haloblockOpen(...args) {
    if (enabled && (strict || (navigator.userActivation && !navigator.userActivation.isActive))) return null;
    return Reflect.apply(nativeOpen,this,args);
  };
  document.addEventListener('click',event => {
    if (!enabled || !strict || event.isTrusted || !(event.target instanceof Element)) return;
    const a=event.target.closest('a[target="_blank"]');
    if (!a) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  },true);
})();
