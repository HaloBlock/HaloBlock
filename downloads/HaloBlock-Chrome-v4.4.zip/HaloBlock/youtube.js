'use strict';

// Best-effort YouTube ad UI cleanup and skip control. Never blocks googlevideo
// media streams; YouTube may change markup or disallow playback with blockers.
(() => {
  const HIDE_STYLE_ID = 'haloblock-youtube-filters';
  const YT_STYLES = `
    ytd-display-ad-renderer,
    ytd-ad-slot-renderer,
    ytd-in-feed-ad-layout-renderer,
    ytd-promoted-sparkles-web-renderer,
    ytd-promoted-video-renderer,
    ytd-banner-promo-renderer,
    ytm-promoted-sparkles-web-renderer,
    yt-mealbar-promo-renderer,
    #player-ads,
    #masthead-ad,
    .ytp-ad-overlay-container,
    .ytp-ad-image-overlay,
    .ytp-ad-text-overlay,
    .ytp-ad-message-container {
      display: none !important;
      visibility: hidden !important;
    }
  `;

  const skipSelectors = [
    '.ytp-ad-skip-button',
    '.ytp-ad-skip-button-modern',
    '.ytp-skip-ad-button',
    '.ytp-ad-skip-button-slot button',
    'button.ytp-ad-skip-button-modern'
  ].join(',');
  let enabled = false;
  let scheduled = false;
  let observer;
  let changedVideo = null;
  let previousMuted = false;

  function updateStyle() {
    const existing = document.getElementById(HIDE_STYLE_ID);
    if (!enabled) {
      existing?.remove();
      if (changedVideo) {
        changedVideo.muted = previousMuted;
        changedVideo = null;
      }
      return;
    }
    if (existing || !document.documentElement) return;
    const el = document.createElement('style');
    el.id = HIDE_STYLE_ID;
    el.textContent = YT_STYLES;
    document.documentElement.appendChild(el);
  }

  function skipVisibleAd() {
    if (!enabled || document.hidden) return;
    const player = document.querySelector('.html5-video-player.ad-showing');
    if (!player) {
      if (changedVideo) {
        changedVideo.muted = previousMuted;
        changedVideo = null;
      }
      return;
    }

    for (const button of document.querySelectorAll(skipSelectors)) {
      if (button.disabled || button.getAttribute('aria-disabled') === 'true') continue;
      if (button.getClientRects().length === 0) continue;
      button.click();
      break;
    }

    const video = player.querySelector('video');
    if (!video) return;
    if (video !== changedVideo) {
      if (changedVideo) changedVideo.muted = previousMuted;
      changedVideo = video;
      previousMuted = video.muted;
    }
    // Keep playback quiet while an ad is active, and try to seek past a short
    // separately identifiable ad. Never seek through normal video playback.
    video.muted = true;
    if (Number.isFinite(video.duration) && video.duration > 1 && video.duration <= 180) {
      try { video.currentTime = Math.max(0, video.duration - 0.15); } catch { /* seek unavailable */ }
    }
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      updateStyle();
      skipVisibleAd();
    }, 200);
  }

  async function sync() {
    try {
      const prefs = await chrome.storage.local.get({ enabled: true, excludedHosts: [] });
      const host = location.hostname.toLowerCase();
      enabled = prefs.enabled !== false &&
        !prefs.excludedHosts.some(site => host === site || host.endsWith(`.${site}`));
    } catch { enabled = false; }
    updateStyle();
    schedule();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && ('enabled' in changes || 'excludedHosts' in changes)) sync();
  });
  if (document.documentElement) {
    observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'aria-disabled'] });
  } else {
    document.addEventListener('readystatechange', () => {
      if (!observer && document.documentElement) {
        observer = new MutationObserver(schedule);
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'aria-disabled'] });
      }
    });
  }
  // Ads can become skippable even when the DOM does not change.
  setInterval(skipVisibleAd, 1100);
  sync();
})();
