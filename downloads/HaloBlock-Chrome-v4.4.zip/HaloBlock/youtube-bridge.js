'use strict';
// ISOLATED world: settings bridge and read-only local diagnostics. No browsing
// data or player contents are transmitted or persisted.
(() => {
  let engine = {ready:false, enabled:false, pruneCount:0};
  window.addEventListener('__haloblock_yt_engine_status_v2', event => {
    try {
      const data = JSON.parse(event.detail);
      if (data?.ready === true && Number.isSafeInteger(data.pruneCount) && data.pruneCount >= 0) {
        engine = {ready:true, enabled:data.enabled === true, pruneCount:data.pruneCount};
      }
    } catch { /* unrecognized event */ }
  });
  async function sync() {
    try {
      const prefs = await chrome.storage.local.get({enabled:true,excludedHosts:[]});
      const host = location.hostname.toLowerCase();
      const excluded = prefs.excludedHosts.some(s => host === s || host.endsWith(`.${s}`));
      window.dispatchEvent(new CustomEvent('__haloblock_yt_config_v1', {detail: prefs.enabled !== false && !excluded}));
    } catch {
      window.dispatchEvent(new CustomEvent('__haloblock_yt_config_v1', {detail: false}));
    }
    window.dispatchEvent(new Event('__haloblock_yt_probe_v2'));
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && ('enabled' in changes || 'excludedHosts' in changes)) sync();
  });
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type !== 'YT_GET_DIAGNOSTICS') return false;
    window.dispatchEvent(new Event('__haloblock_yt_probe_v2'));
    reply({ ...engine, adShowing:!!document.querySelector('.html5-video-player.ad-showing'), version:2 });
    return false;
  });
  sync();
})();
