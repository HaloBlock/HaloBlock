'use strict';
(() => {
  const hostname=location.hostname.toLowerCase();
  const matches=domain=>hostname===domain || hostname.endsWith('.'+domain);
  async function syncPolicy(){
    try {
      const prefs=await chrome.storage.local.get({enabled:true,excludedHosts:[],popupAllowedHosts:[]});
      const enabled=prefs.enabled!==false && !prefs.excludedHosts.some(matches);
      const strict=!prefs.popupAllowedHosts.some(matches);
      document.dispatchEvent(new CustomEvent('haloblock:popup-policy',{detail:{enabled,strict}}));
    } catch {
      // Content scripts should never open unexpected tabs because storage failed.
      document.dispatchEvent(new CustomEvent('haloblock:popup-policy',{detail:{enabled:true,strict:true}}));
    }
  }
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area==='local' && ['enabled','excludedHosts','popupAllowedHosts'].some(key=>key in changes)) syncPolicy();
  });
  syncPolicy();
})();
