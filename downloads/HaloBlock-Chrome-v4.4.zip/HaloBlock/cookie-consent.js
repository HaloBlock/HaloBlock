'use strict';
// Conservative, provider-specific consent handling. Never auto-accepts, never
// hides a dialog without sending a rejection, and never invents a choice.
(() => {
  const SELECTORS = [
    '#onetrust-reject-all-handler',               // OneTrust
    '#CybotCookiebotDialogBodyButtonDecline',   // Cookiebot
    '#didomi-notice-disagree-button'             // Didomi
  ];
  const clicked = new WeakSet();
  const hostname = location.hostname.toLowerCase();
  const matches = d => hostname === d || hostname.endsWith('.' + d);
  let enabled = false;
  let scanTimer;

  function visible(element) {
    if (!(element instanceof HTMLElement) || element.disabled) return false;
    const rect = element.getBoundingClientRect();
    const css = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && css.display !== 'none' &&
      css.visibility !== 'hidden' && Number(css.opacity) > 0;
  }
  function rejectRecognized() {
    if (!enabled) return;
    for (const selector of SELECTORS) {
      const button = document.querySelector(selector);
      if (button && !clicked.has(button) && visible(button)) {
        clicked.add(button); // Never hammer a provider's rejection endpoint.
        button.click();
      }
    }
  }
  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = null; rejectRecognized(); }, 250);
  }
  async function sync() {
    try {
      const pref = await chrome.storage.local.get({
        enabled: true, excludedHosts: [], autoRejectCookies: true
      });
      enabled = pref.enabled !== false && pref.autoRejectCookies !== false &&
        !pref.excludedHosts.some(matches);
      if (enabled) scheduleScan();
    } catch { enabled = false; }
  }
  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement || document, { childList: true, subtree: true });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && ['enabled', 'excludedHosts', 'autoRejectCookies'].some(k => k in changes)) sync();
  });
  sync();
})();
