'use strict';
// Runs at document_start in YouTube's MAIN world. Remove known ad scheduling
// instructions from player metadata before YouTube's player processes them.
// This is a best-effort compatibility layer: NEVER block or rewrite video media.
(() => {
  const GUARD = '__haloblockYoutubeMetadataGuardV2';
  if (window[GUARD]) return;
  Object.defineProperty(window, GUARD, {value: true, configurable: false});

  let enabled = true;
  window.addEventListener('__haloblock_yt_config_v1', event => {
    if (typeof event.detail === 'boolean') enabled = event.detail;
  });

  const AD_KEYS = ['adPlacements', 'adSlots', 'playerAds'];
  const SERIALIZED_PLAYER_KEYS = ['raw_player_response', 'player_response', 'playerResponse'];
  const nativeJSONParse = JSON.parse;
  let pruneCount = 0;
  function emitStatus() {
    if (typeof CustomEvent !== 'function' || typeof window.dispatchEvent !== 'function') return;
    window.dispatchEvent(new CustomEvent('__haloblock_yt_engine_status_v2', {
      detail: JSON.stringify({ready:true, enabled, pruneCount})
    }));
  }
  window.addEventListener('__haloblock_yt_probe_v2', emitStatus);
  const MAX_NODES = 25000;
  const MAX_RESPONSE_BYTES = 14 * 1024 * 1024;
  const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

  // Only these YouTube-owned endpoints carry player/browse/shorts metadata.
  function relevantURL(value) {
    try {
      const url = new URL(value, location.href);
      if (!(url.hostname === 'youtube.com' || url.hostname.endsWith('.youtube.com'))) return false;
      return /^\/youtubei\/v1\/(?:player|get_watch|browse|next|search|playlist|reel\/reel_watch_sequence|reel_watch_sequence)(?:[/?]|$)/.test(url.pathname);
    } catch { return false; }
  }

  // Mutates ONLY specific YouTube ad metadata. Never changes streamingData,
  // playabilityStatus, media URLs or the actual video itself.
  function removeAdInstructions(root, depth = 0) {
    if (!enabled || !root || typeof root !== 'object') return false;
    const seen = new WeakSet();
    const stack = [root];
    let visited = 0;
    let changed = false;
    while (stack.length && visited < MAX_NODES) {
      const obj = stack.pop();
      if (!obj || typeof obj !== 'object' || seen.has(obj)) continue;
      seen.add(obj);
      visited++;
      if (Array.isArray(obj)) {
        for (let i = 0; i < obj.length; i++) if (obj[i] && typeof obj[i] === 'object') stack.push(obj[i]);
        continue;
      }
      for (const key of AD_KEYS) {
        if (own(obj, key)) { try {delete obj[key]; changed = true;} catch { /* frozen object */ } }
      }
      // YouTube also uses player configuration with JSON encoded as a string.
      // Only touch named player-response properties, and bound recursion depth.
      if (depth < 2) for (const key of SERIALIZED_PLAYER_KEYS) {
        if (typeof obj[key] !== 'string') continue;
        const updated = stripJSON(obj[key], depth + 1);
        if (updated !== null) {
          try {obj[key] = updated; changed = true;} catch { /* immutable */ }
        }
      }
      if (obj.playerConfig && typeof obj.playerConfig === 'object' && own(obj.playerConfig, 'ssapConfig')) {
        try {delete obj.playerConfig.ssapConfig; changed = true;} catch { /* frozen object */ }
      }
      // Shorts sometimes include a dedicated, explicitly flagged ad entry.
      if (Array.isArray(obj.entries)) {
        const count = obj.entries.length;
        const isAdEntry = item => item?.command?.reelWatchEndpoint?.adClientParams?.isAd === true;
        if (obj.entries.some(isAdEntry)) {
          try {obj.entries = obj.entries.filter(item => !isAdEntry(item)); changed ||= obj.entries.length !== count;}
          catch { /* immutable collection */ }
        }
      }
      for (const key of Object.keys(obj)) {
        const value = obj[key];
        if (value && typeof value === 'object' && !seen.has(value)) stack.push(value);
      }
    }
    if (changed) { pruneCount++; emitStatus(); }
    return changed;
  }

  function stripJSON(raw, depth = 0) {
    if (!enabled || typeof raw !== 'string' || !raw || raw.length > MAX_RESPONSE_BYTES ||
        !/(?:"adPlacements"|"adSlots"|"playerAds"|"ssapConfig"|"isAd")/.test(raw)) return null;
    try {
      const prefix = raw.startsWith(")]}'") ? raw.slice(0, raw.indexOf('\n') + 1) : '';
      const body = prefix ? raw.slice(prefix.length) : raw;
      // Use the captured native parse, so our parse observer never recursively
      // invokes itself while rewriting an incoming player JSON string.
      const parsed = Reflect.apply(nativeJSONParse, JSON, [body]);
      if (!removeAdInstructions(parsed, depth)) return null;
      return prefix + JSON.stringify(parsed);
    } catch { return null; }
  }

  function protectGlobal(name) {
    try {
      const original = Object.getOwnPropertyDescriptor(window, name);
      if (original && !original.configurable) return;
      let stored = original && own(original, 'value') ? original.value : undefined;
      if (stored) removeAdInstructions(stored);
      Object.defineProperty(window, name, {
        configurable: true, enumerable: true,
        get() { return stored; },
        set(value) { stored = value; if (enabled) removeAdInstructions(stored); }
      });
    } catch { /* Leave YouTube globals alone if the page locked them. */ }
  }
  protectGlobal('ytInitialPlayerResponse');
  protectGlobal('ytInitialData');

  // Initial YouTube HTML sometimes initializes via ytplayer.config.args rather
  // than ytInitialPlayerResponse. Instrument only those known player-config
  // properties; do not intercept general YouTube application state.
  const armed = new WeakMap();
  function armProperty(obj, key, callback) {
    if (!obj || typeof obj !== 'object') return;
    let names = armed.get(obj);
    if (!names) { names = new Set(); armed.set(obj, names); }
    if (names.has(key)) return;
    const descriptor = Object.getOwnPropertyDescriptor(obj, key);
    if (descriptor && !descriptor.configurable) {
      try { callback(obj[key]); } catch { /* inaccessible */ }
      return;
    }
    let stored;
    try { stored = descriptor?.get ? descriptor.get.call(obj) : descriptor?.value; }
    catch { return; }
    const writable = !descriptor || 'set' in descriptor || descriptor.writable !== false;
    if (!writable || (descriptor?.get && !descriptor?.set)) { callback(stored); return; }
    try {
      Object.defineProperty(obj, key, {
        configurable: true,
        enumerable: descriptor?.enumerable ?? true,
        get() { return descriptor?.get ? descriptor.get.call(this) : stored; },
        set(value) {
          if (descriptor?.set) descriptor.set.call(this, value);
          else stored = value;
          try { callback(value); } catch { /* preserve original behavior */ }
        }
      });
      names.add(key);
      callback(stored);
    } catch { /* Preserve YouTube's own property behavior. */ }
  }
  function armConfig(config) {
    if (!config || typeof config !== 'object') return;
    if (enabled) removeAdInstructions(config);
    armProperty(config, 'args', args => { if (enabled) removeAdInstructions(args); });
  }
  function armYtPlayer(holder) {
    if (!holder || typeof holder !== 'object') return;
    if (enabled) removeAdInstructions(holder);
    armProperty(holder, 'config', armConfig);
  }
  // The global can be assigned before or after the rest of the app starts.
  try {
    let current = window.ytplayer;
    const prior = Object.getOwnPropertyDescriptor(window, 'ytplayer');
    if (!prior || (prior.configurable && !prior.get && !prior.set)) {
      Object.defineProperty(window, 'ytplayer', {
        configurable: true, enumerable: true,
        get() { return current; },
        set(value) { current = value; armYtPlayer(value); }
      });
    }
    armYtPlayer(current);
  } catch { /* Keep site working if its globals are protected. */ }

  // Catch player JSON parsed from inline/serialized settings, not only network
  // fetch/XHR responses. Change only objects containing the known ad metadata.
  try {
    JSON.parse = function (raw, reviver) {
      const result = arguments.length > 1
        ? Reflect.apply(nativeJSONParse, JSON, [raw, reviver])
        : Reflect.apply(nativeJSONParse, JSON, [raw]);
      if (enabled && typeof raw === 'string' && raw.length <= MAX_RESPONSE_BYTES &&
          /\"(?:adPlacements|adSlots|playerAds|ssapConfig)\"/.test(raw) && result && typeof result === 'object') {
        try { removeAdInstructions(result); } catch { /* Never interrupt JSON parsing. */ }
      }
      return result;
    };
  } catch { /* Preserve original JSON.parse when locked. */ }
  emitStatus();

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = function (...args) {
      const request = Reflect.apply(originalFetch, this, args);
      if (!enabled) return request;
      return Promise.resolve(request).then(async response => {
        // Use the actual network response URL, NOT a potentially spoofed Request URL.
        if (!response || !response.ok || !relevantURL(response.url)) return response;
        try {
          const len = Number(response.headers?.get('content-length'));
          if (len > MAX_RESPONSE_BYTES) return response;
          const raw = await response.clone().text();
          const updated = stripJSON(raw);
          if (updated === null) return response;
          const headers = new Headers(response.headers);
          // Rewritten body is UTF-8 plain text. Old byte lengths / compression
          // metadata are no longer valid and must not be forwarded.
          for (const key of ['content-length', 'content-encoding', 'content-md5', 'etag']) headers.delete(key);
          const replacement = new Response(updated, {status: response.status, statusText: response.statusText, headers});
          for (const key of ['url', 'redirected', 'type']) {
            try {Object.defineProperty(replacement, key, {configurable: true, get: () => response[key]});} catch { /* optional */ }
          }
          return replacement;
        } catch { return response; }
      });
    };
  }

  const XHR = window.XMLHttpRequest;
  if (XHR && XHR.prototype) {
    const proto = XHR.prototype;
    const textProp = Object.getOwnPropertyDescriptor(proto, 'responseText');
    const responseProp = Object.getOwnPropertyDescriptor(proto, 'response');
    const rewritten = new WeakMap();
    function getReplacement(xhr) {
      if (!enabled || xhr.readyState !== 4 || !relevantURL(xhr.responseURL)) return null;
      if (rewritten.has(xhr)) return rewritten.get(xhr);
      let result = null;
      try {
        if (xhr.responseType === '' || xhr.responseType === 'text') {
          result = stripJSON(textProp.get.call(xhr));
        } else if (xhr.responseType === 'json') {
          const data = responseProp.get.call(xhr);
          if (data && removeAdInstructions(data)) result = data;
        }
      } catch { /* inaccessible response */ }
      rewritten.set(xhr, result);
      return result;
    }
    if (textProp?.get && textProp.configurable) {
      Object.defineProperty(proto, 'responseText', {
        configurable: true, enumerable: textProp.enumerable,
        get() {
          const updated = getReplacement(this);
          return typeof updated === 'string' ? updated : textProp.get.call(this);
        }
      });
    }
    if (responseProp?.get && responseProp.configurable) {
      Object.defineProperty(proto, 'response', {
        configurable: true, enumerable: responseProp.enumerable,
        get() {
          const updated = getReplacement(this);
          return updated !== null ? updated : responseProp.get.call(this);
        }
      });
    }
  }
})();
