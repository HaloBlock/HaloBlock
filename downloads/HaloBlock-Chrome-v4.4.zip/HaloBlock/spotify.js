'use strict';
// Spotify Web Player ONLY. Deliberately avoid network-blocking audio streams:
// their URLs may be shared with music, and blocking them can break playback.
// This optional, best-effort safeguard mutes currently playing HTML media only
// when Spotify itself marks its active item as an advertisement.
(() => {
  const hostname=location.hostname.toLowerCase();
  if (hostname!=='open.spotify.com') return;
  const ownMute=new Map();
  const clickedAdSkip=new WeakSet();
  let enabled=true;
  let checkScheduled=false;
  let lastReported=null, lastReportTime=0;

  const allowed=domain=>hostname===domain||hostname.endsWith('.'+domain);
  async function syncSettings(){
    try {
      const options=await chrome.storage.local.get({enabled:true,excludedHosts:[],spotifyMuteAds:true});
      enabled=options.enabled!==false && options.spotifyMuteAds!==false &&
        !(options.excludedHosts||[]).some(allowed);
    } catch { enabled=false; } // Never modify playback if extension settings are unavailable.
    scheduleCheck();
  }

  function currentAdDetected(){
    // Spotify has historically used the .ad-playing state on its player.
    if (document.querySelector('body.ad-playing, #main.ad-playing, .Root.ad-playing, [data-testid="now-playing-bar"].ad-playing')) return true;
    // Inspect CURRENT now-playing metadata, not arbitrary ad copy elsewhere.
    const current=document.querySelector('[data-testid="now-playing-widget"], [data-testid="now-playing-bar"]');
    if (!current) return false;
    if (current.querySelector('[aria-label="Advertisement"], [aria-label="Audio advertisement"], [data-testid="advertisement-label"]')) return true;
    for (const element of current.querySelectorAll('span,small,div')) {
      // Only leaf labels to avoid interpreting an artist/title as an ad state.
      if (element.children.length===0 && /^(advertisement|audio ad|ad playing)$/i.test((element.textContent||'').trim())) return true;
    }
    return false;
  }

  function restore(){
    for (const [media,wasMuted] of ownMute) {
      // Restore only if it is still muted; don't override user changes to sound.
      if (media.isConnected && media.muted) media.muted=wasMuted;
    }
    ownMute.clear();
  }

  function check(){
    checkScheduled=false;
    const detected=enabled && currentAdDetected();
    // Best effort also mute browser tab audio: Spotify can use detached media.
    // Heartbeat handles worker suspension without sending on every DOM change.
    if(detected!==lastReported || Date.now()-lastReportTime>8000){
      lastReported=detected;lastReportTime=Date.now();
      chrome.runtime.sendMessage({type:'SPOTIFY_AD_STATE',adPlaying:detected}).catch(()=>{});
    }
    if (!detected) {restore();return;}
    for (const media of document.querySelectorAll('audio,video')) {
      if (!(media instanceof HTMLMediaElement) || ownMute.has(media)) continue;
      ownMute.set(media,media.muted);
      if (!media.muted) media.muted=true;
    }
    // Only click an explicit SKIP AD control; never click the normal track-next
    // button, which can lose songs or disrupt playback.
    for (const btn of document.querySelectorAll('button[aria-label],button[title]')) {
      const name=(btn.getAttribute('aria-label')||btn.getAttribute('title')||'').trim();
      if (!/^skip (?:this )?(?:ad|advertisement)$/i.test(name) || btn.disabled || clickedAdSkip.has(btn)) continue;
      clickedAdSkip.add(btn);
      btn.click();
      break;
    }
  }
  function scheduleCheck(){
    if (checkScheduled) return;
    checkScheduled=true;
    setTimeout(check,200);
  }
  const observer=new MutationObserver(scheduleCheck);
  function start(){
    if (document.body) observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','aria-label','title']});
    syncSettings();
    setInterval(scheduleCheck,1500);
  }
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area==='local' && ['enabled','excludedHosts','spotifyMuteAds'].some(k=>k in changes)) syncSettings();
  });
  addEventListener('pagehide',()=>{restore();chrome.runtime.sendMessage({type:'SPOTIFY_AD_STATE',adPlaying:false}).catch(()=>{});},{once:true});
})();
