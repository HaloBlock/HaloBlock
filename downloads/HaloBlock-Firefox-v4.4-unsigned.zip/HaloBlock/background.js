'use strict';
if (typeof importScripts === 'function') importScripts('filter-engine.js');

// Browser-wide default protection. Subscribed lists are fetched only from these
// fixed HTTPS origins; no browsing history, URL, or page contents are uploaded.
const SOURCES = [
  // Supported declarative rules only: cosmetic/scriptlet syntax that requires
  // procedural execution is intentionally not translated into blocking rules.
  { id:'easylist', name:'EasyList', url:'https://easylist.to/easylist/easylist.txt', blocks:10800, allows:500, cosmetic:6200 },
  { id:'adguard-base', name:'AdGuard Base', url:'https://filters.adtidy.org/extension/chromium/filters/2.txt', blocks:6700, allows:500, cosmetic:5600 },
  { id:'easyprivacy', name:'EasyPrivacy', url:'https://easylist.to/easylist/easyprivacy.txt', blocks:4400, allows:400, cosmetic:1200 },
  { id:'adguard-dns', name:'AdGuard DNS', url:'https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt', blocks:2300, allows:250, cosmetic:600 }
];
const RULESET_IDS=['core_ads','popups','compiled_subscriptions'];
const MAX_CUSTOM_DOMAINS=3500, MAX_ALLOWED_SITES=500, MAX_POPUP_ALLOWED_SITES=500;
const REMOTE_START=10000, CUSTOM_START=100, SITE_ALLOW_START=5000, SITE_FRAME_ALLOW_START=5600, OFF_RULE=9900;
const ALL_TYPES = [...HaloBlockFilterEngine.types,'main_frame'];
const DEFAULTS={enabled:true,excludedHosts:[],blockedHosts:[],popupAllowedHosts:[],spotifyMuteAds:true,autoRejectCookies:true};
const UPDATE_INTERVAL_MINUTES=24*60;
const REMOTE_MAX_RULES=25000; // under Chrome's 30k safe dynamic limit, leaving space for custom rules

function domain(input){
  const name=typeof input==='string' ? input.trim().toLowerCase().replace(/\.$/,'') : '';
  return HaloBlockFilterEngine.validDomain(name) ? name : null;
}
function clean(value,max) {
  if (!Array.isArray(value) || value.length>max) throw new Error(`Invalid domains or maximum ${max} exceeded.`);
  const normalized=value.map(domain);
  if (normalized.some(v=>!v)) throw new Error('Invalid hostname in the list.');
  return [...new Set(normalized)].sort();
}
async function settings(){
  const v=await chrome.storage.local.get(DEFAULTS);
  return { enabled:v.enabled!==false, excludedHosts:clean(v.excludedHosts||[],MAX_ALLOWED_SITES),
    blockedHosts:clean(v.blockedHosts||[],MAX_CUSTOM_DOMAINS), popupAllowedHosts:clean(v.popupAllowedHosts||[],MAX_POPUP_ALLOWED_SITES), spotifyMuteAds:v.spotifyMuteAds!==false, autoRejectCookies:v.autoRejectCookies!==false };
}
function localRules(cfg){
  const list=[];
  for (const [i,d] of cfg.blockedHosts.entries()) list.push({id:CUSTOM_START+i,priority:50,action:{type:'block'},condition:{urlFilter:`||${d}^`,resourceTypes:ALL_TYPES}});
  for (const [i,d] of cfg.excludedHosts.entries()) {
    list.push({id:SITE_ALLOW_START+i,priority:1000,action:{type:'allow'},condition:{initiatorDomains:[d],resourceTypes:ALL_TYPES}});
    // Allow the paused website's main frame and the whole document hierarchy.
    list.push({id:SITE_FRAME_ALLOW_START+i,priority:1000,action:{type:'allowAllRequests'},condition:{requestDomains:[d],resourceTypes:['main_frame']}});
  }
  if (!cfg.enabled) list.push({id:OFF_RULE, priority:2000, action:{type:'allow'},condition:{urlFilter:'|http',resourceTypes:ALL_TYPES}});
  return list;
}
let job=Promise.resolve();
function enqueue(fn) { job=job.catch(e=>console.error('HaloBlock background task failed',e)).then(fn); return job; }
async function reconcile(){
  const cfg=await settings();
  const enabled=await chrome.declarativeNetRequest.getEnabledRulesets();
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds:cfg.enabled ? RULESET_IDS.filter(x=>!enabled.includes(x)) : [],
    disableRulesetIds:cfg.enabled ? [] : RULESET_IDS.filter(x=>enabled.includes(x))
  });
  const old=await chrome.declarativeNetRequest.getDynamicRules();
  const oldLocal=old.filter(r=>r.id<REMOTE_START).map(r=>r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:oldLocal,addRules:localRules(cfg)});
}
function mergeCSS(list,global,perSite,exceptions){
  for (const selector of list.generic) if (global.size<6200) global.add(selector);
  for (const [host,selectors] of Object.entries(list.siteExclusions)) {
    if (!exceptions[host]) exceptions[host]=[];
    if (exceptions[host].length<350) exceptions[host].push(...selectors.slice(0,350-exceptions[host].length));
  }
  for (const [host,selectors] of Object.entries(list.site)) {
    if (!perSite[host]) perSite[host]=[];
    if (perSite[host].length<700) perSite[host].push(...selectors.slice(0,700-perSite[host].length));
  }
}
function filterSummary(){return chrome.storage.local.get({remoteRuleCount:0,remoteBlockRuleCount:0,remoteFilterStatus:'Not downloaded yet',lastFilterUpdate:0,sourceStatus:[],cosmeticRuleCount:0,popupNavigationRules:0});}

async function refreshRemote(force=false){
  const prior=await chrome.storage.local.get({lastFilterUpdate:0,remoteRuleCount:0,cosmeticGlobal:[],cosmeticSites:{}});
  if (!force && prior.lastFilterUpdate && Date.now()-prior.lastFilterUpdate<UPDATE_INTERVAL_MINUTES*60000) return;
  const allBlock=[],allAllow=[],status=[],global=new Set(),sites={},siteExclusions={}, seen=new Set();
  const confirmedAdDomains=new Map();
  let successes=0;
  for (const src of SOURCES) {
    try {
      const controller=new AbortController();
      const abortId=setTimeout(()=>controller.abort(),30000);
      let response;
      try { response=await fetch(src.url,{cache:'no-store',signal:controller.signal}); }
      finally { clearTimeout(abortId); }
      if (!response.ok) throw new Error('HTTP '+response.status);
      const text=await response.text();
      if (text.length<3000 || text.length>12000000) throw new Error('Filter download has unexpected size');
      const data=HaloBlockFilterEngine.parse(text,{block:src.blocks,allow:src.allows,cosmetic:src.cosmetic});
      if (data.blocks.length<100) throw new Error('Too few supported filter rules');
      for (const r of data.blocks) {
        // Cross-check plain ad-domain filters independently across subscriptions.
        // Navigation rules are generated ONLY for independently corroborated
        // advertising hosts, not for arbitrary URL patterns or first-party media.
        const m=/^\|\|([a-z0-9-]+(?:\.[a-z0-9-]+)+)\^$/.exec(r.condition.urlFilter||'');
        if (m && !r.condition.initiatorDomains && !r.condition.excludedInitiatorDomains &&
            !r.condition.domainType && !r.condition.isUrlFilterCaseSensitive) {
          if (!confirmedAdDomains.has(m[1])) confirmedAdDomains.set(m[1],new Set());
          confirmedAdDomains.get(m[1]).add(src.id);
        }
        const key=JSON.stringify(r.condition)+'block';
        if (!seen.has(key)) {seen.add(key);allBlock.push(r);}
      }
      for (const r of data.allows) {
        const key=JSON.stringify(r.condition)+'allow';
        if (!seen.has(key)) {seen.add(key);allAllow.push(r);}
      }
      mergeCSS(data,global,sites,siteExclusions);
      status.push({name:src.name,ok:true,rules:data.blocks.length});
      successes++;
    } catch(e) {
      status.push({name:src.name,ok:false,error:String(e.message||e).slice(0,100)});
    }
  }
  if (!successes) {
    await chrome.storage.local.set({remoteFilterStatus:'Update failed; using previously installed filters or built-in fallback',sourceStatus:status});
    throw new Error('Could not download any subscribed filter lists.');
  }
  // A narrow additional layer for popunder destinations: only exact domain
  // rules independently confirmed by two different public subscriptions.
  const navigation=[];
  const mediaLike=/(?:^|\.)(?:spotify|youtube|googlevideo|netflix|google|cloudfront|akamai|apple|amazonaws|microsoft|github|mozilla)\./;
  for (const [host,sources] of confirmedAdDomains) {
    if (sources.size<2 || mediaLike.test(host) || !HaloBlockFilterEngine.validDomain(host)) continue;
    navigation.push({action:{type:'block'},priority:3,condition:{urlFilter:`||${host}^`,resourceTypes:['main_frame']}});
    if (navigation.length>=1400) break;
  }
  // Reserve room for exception rules and confirmed navigation destinations.
  // Important network blocks go first; never exceed the Chrome rule budget.
  const keepAllows=allAllow.slice(0,Math.min(1900,allAllow.length));
  const blockLimit=REMOTE_MAX_RULES-keepAllows.length-navigation.length;
  const sortedBlocks=allBlock.map((r,i)=>({r,i})).sort((a,b)=>b.r.priority-a.r.priority || a.i-b.i);
  const merged=[...sortedBlocks.slice(0,blockLimit).map(x=>x.r),...navigation,...keepAllows]
    .map((rule,i)=>({...rule,id:REMOTE_START+i}));
  if (merged.length<100) throw new Error('No usable list rules');
  // Atomic update: retain the previous remote set if the new set is invalid.
  const old=await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds:old.filter(r=>r.id>=REMOTE_START).map(r=>r.id), addRules:merged
  });
  // CSS is supplementary: an existing, good network filter set survives any
  // storage failure and applies to ALL HTTP/HTTPS websites.
  const cosmeticSites=Object.fromEntries(Object.entries(sites).filter(([k,v])=>v.length && k.length<200));
  const cosmeticExclusions=Object.fromEntries(Object.entries(siteExclusions).filter(([k,v])=>v.length && k.length<200));
  await chrome.storage.local.set({
    cosmeticGlobal:[...global], cosmeticSites, cosmeticExclusions,
    lastFilterUpdate:Date.now(), remoteRuleCount:merged.length, remoteBlockRuleCount:Math.min(blockLimit, allBlock.length),
    remoteFilterStatus:successes===SOURCES.length?'Current':'Partially updated',
    popupNavigationRules:navigation.length,
    sourceStatus:status, cosmeticRuleCount:global.size + Object.values(sites).reduce((n,arr)=>n+arr.length,0)
  });
}

chrome.runtime.onInstalled.addListener(()=>{
  chrome.alarms.create('refresh-filters',{periodInMinutes:UPDATE_INTERVAL_MINUTES});
  enqueue(async()=>{await reconcile();await refreshRemote(false);}).catch(console.warn);
});
chrome.runtime.onStartup.addListener(()=>{
  chrome.alarms.create('refresh-filters',{periodInMinutes:UPDATE_INTERVAL_MINUTES});
  enqueue(async()=>{await reconcile();await refreshRemote(false);}).catch(console.warn);
});
chrome.alarms.onAlarm.addListener(alarm=>{
  if (alarm.name==='refresh-filters') enqueue(()=>refreshRemote(true)).catch(console.warn);
});
chrome.storage.onChanged.addListener((changes,area)=>{
  if (area==='local' && ['enabled','excludedHosts','blockedHosts'].some(k=>k in changes)) enqueue(reconcile).catch(console.warn);
});

// Spotify sound is sometimes played by detached/hidden media elements that a
// DOM script cannot access. Only Spotify's TOP frame can ask the background to
// mute that one browser tab. Preserve pre-existing user mute state, and use
// session storage so a suspended/restarted service worker can restore it.
const spotifyTabTasks=new Map();
function queueSpotifyTab(tabId,fn){
  const prev=spotifyTabTasks.get(tabId)||Promise.resolve();
  const next=prev.catch(()=>{}).then(fn);
  spotifyTabTasks.set(tabId,next);
  next.finally(()=>{if(spotifyTabTasks.get(tabId)===next)spotifyTabTasks.delete(tabId);}).catch(()=>{});
  return next;
}
async function adjustSpotifyTabMute(tabId,adPlaying){
  const key='spotifyTabMute_'+tabId;
  const data=await chrome.storage.session.get(key);
  const wasOurs=data[key]===true;
  let tab;
  try {tab=await chrome.tabs.get(tabId);} catch {await chrome.storage.session.remove(key);return;}
  if(adPlaying){
    if(wasOurs||tab.mutedInfo?.muted)return;
    // Record BEFORE muting so we can recover when the worker restarts.
    await chrome.storage.session.set({[key]:true});
    try {await chrome.tabs.update(tabId,{muted:true});}
    catch(e){await chrome.storage.session.remove(key);throw e;}
  }else if(wasOurs){
    const info=tab.mutedInfo;
    if(info?.muted && info.reason==='extension' && info.extensionId===chrome.runtime.id) {
      await chrome.tabs.update(tabId,{muted:false});
    }
    await chrome.storage.session.remove(key);
  }
}
chrome.tabs.onUpdated.addListener((id,change)=>{
  if(change.status==='loading')queueSpotifyTab(id,()=>adjustSpotifyTabMute(id,false)).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(id=>{
  chrome.storage.session.remove('spotifyTabMute_'+id).catch(()=>{});
});

chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(msg?.type==='SPOTIFY_AD_STATE'){
    const topPage=sender?.frameId===0 && sender?.tab?.id>=0;
    let spotify=false;
    try {spotify=new URL(sender.url).hostname==='open.spotify.com';} catch {}
    if(!topPage||!spotify||typeof msg.adPlaying!=='boolean'){
      reply({ok:false,error:'Unexpected message origin'});return false;
    }
    queueSpotifyTab(sender.tab.id,async()=>{
      const cfg=await settings();
      const allowed=cfg.enabled && cfg.spotifyMuteAds && !cfg.excludedHosts.some(d=>'open.spotify.com'===d||'open.spotify.com'.endsWith('.'+d));
      await adjustSpotifyTabMute(sender.tab.id,msg.adPlaying&&allowed);
    }).then(()=>reply({ok:true})).catch(e=>reply({ok:false,error:String(e.message).slice(0,120)}));
    return true;
  }
  if (msg?.type==='UPDATE_SETTINGS') {
    enqueue(async()=>{
      if (!msg.patch || typeof msg.patch!=='object' || Array.isArray(msg.patch) ||
          !Object.keys(msg.patch).length || Object.keys(msg.patch).some(k=>!(k in DEFAULTS))) throw new Error('Invalid settings update');
      const cfg=await settings();
      for (const [key,value] of Object.entries(msg.patch)) {
        if (key==='enabled' || key==='spotifyMuteAds' || key==='autoRejectCookies') {if (typeof value!=='boolean') throw new Error('Invalid protection setting');cfg[key]=value;}
        else cfg[key]=clean(value,key==='blockedHosts'?MAX_CUSTOM_DOMAINS:key==='popupAllowedHosts'?MAX_POPUP_ALLOWED_SITES:MAX_ALLOWED_SITES);
      }
      await chrome.storage.local.set(cfg);
      await reconcile();
      return cfg;
    }).then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,error:e.message}));
    return true;
  }
  if (msg?.type==='UPDATE_FILTERS') {
    enqueue(async()=>{await refreshRemote(true);return await filterSummary();})
      .then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,error:e.message}));
    return true;
  }
  if (msg?.type==='GET_FILTER_STATUS') {
    filterSummary().then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,error:e.message}));
    return true;
  }
  return false;
});
